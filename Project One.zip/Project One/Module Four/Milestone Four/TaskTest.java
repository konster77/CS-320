import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test", "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test", "Description");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "NameThatIsWayTooLongForTheLimit", "Description");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Test", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Test", "This description is way too long to be accepted because it has more than fifty characters.");
        });
    }
}
