import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    @Test
    public void testAddAndRetrieveTask() {
        Task task = new Task("001", "Test", "Testing task service.");
        service.addTask(task);
        assertEquals(task, service.getTask("001"));
    }

    @Test
    public void testAddDuplicateTaskThrowsException() {
        Task task = new Task("001", "Test", "Testing task service.");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("001", "Test2", "Another task"));
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("002", "ToDelete", "Task to delete");
        service.addTask(task);
        service.deleteTask("002");
        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("002");
        });
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("003", "Initial", "Description");
        service.addTask(task);
        service.updateTaskName("003", "Updated Name");
        assertEquals("Updated Name", service.getTask("003").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("004", "Initial", "Old Description");
        service.addTask(task);
        service.updateTaskDescription("004", "New Description");
        assertEquals("New Description", service.getTask("004").getDescription());
    }
}
