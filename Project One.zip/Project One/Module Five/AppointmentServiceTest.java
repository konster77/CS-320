import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        appointment = new Appointment("123", calendar.getTime(), "Checkup");
    }

    @Test
    public void testAddAppointment() {
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("123"));
    }

    @Test
    public void testAddDuplicateAppointmentId() {
        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment); // duplicate ID
        });
    }

    @Test
    public void testDeleteAppointment() {
        service.addAppointment(appointment);
        service.deleteAppointment("123");
        assertNull(service.getAppointment("123"));
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}
