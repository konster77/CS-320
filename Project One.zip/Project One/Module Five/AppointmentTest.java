import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("12345", futureDate, "Doctor Visit");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor Visit", appointment.getDescription());
        assertEquals(futureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testInvalidAppointmentId() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, calendar.getTime(), "Checkup");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", calendar.getTime(), "Checkup");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", calendar.getTime(), "Past Date");
        });
    }

    @Test
    public void testInvalidDescription() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "A".repeat(51));
        });
    }
}
